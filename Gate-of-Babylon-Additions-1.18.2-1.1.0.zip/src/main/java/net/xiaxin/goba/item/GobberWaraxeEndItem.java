
package net.xiaxin.goba.item;

import net.xiaxin.goba.init.GateOfBabylonAdditionsModTabs;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

public class GobberWaraxeEndItem extends AxeItem {
	public GobberWaraxeEndItem() {
		super(new Tier() {
			public int getUses() {
				return 8000;
			}

			public float getSpeed() {
				return 16f;
			}

			public float getAttackDamageBonus() {
				return 21f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.EMPTY;
			}
		}, 1, -3.5f, new Item.Properties().tab(GateOfBabylonAdditionsModTabs.TAB_GATEOF_BABYLON_ADDITIONS));
	}
}
