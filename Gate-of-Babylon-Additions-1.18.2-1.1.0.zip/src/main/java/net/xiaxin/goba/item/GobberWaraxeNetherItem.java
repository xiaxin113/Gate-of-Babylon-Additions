
package net.xiaxin.goba.item;

import net.xiaxin.goba.init.GateOfBabylonAdditionsModTabs;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

public class GobberWaraxeNetherItem extends AxeItem {
	public GobberWaraxeNetherItem() {
		super(new Tier() {
			public int getUses() {
				return 5200;
			}

			public float getSpeed() {
				return 14f;
			}

			public float getAttackDamageBonus() {
				return 18f;
			}

			public int getLevel() {
				return 3;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.EMPTY;
			}
		}, 1, -3.5f, new Item.Properties().tab(GateOfBabylonAdditionsModTabs.TAB_GATEOF_BABYLON_ADDITIONS));
	}
}
