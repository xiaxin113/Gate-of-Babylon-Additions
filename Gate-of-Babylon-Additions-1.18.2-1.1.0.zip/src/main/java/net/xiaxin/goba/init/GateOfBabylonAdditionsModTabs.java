
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.xiaxin.goba.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class GateOfBabylonAdditionsModTabs {
	public static CreativeModeTab TAB_GATEOF_BABYLON_ADDITIONS;

	public static void load() {
		TAB_GATEOF_BABYLON_ADDITIONS = FabricItemGroupBuilder.create(new ResourceLocation("gate_of_babylon_additions", "gateof_babylon_additions"))
				.icon(() -> new ItemStack(GateOfBabylonAdditionsModItems.GOBBER_BROADSWORD)).build();
	}
}
