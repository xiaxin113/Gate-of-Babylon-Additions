
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.xiaxin.goba.init;

import net.xiaxin.goba.item.TerrasteelKatanaItem;
import net.xiaxin.goba.item.TerraWaraxeItem;
import net.xiaxin.goba.item.TerraSpearItem;
import net.xiaxin.goba.item.TerraRapierItem;
import net.xiaxin.goba.item.TerraHaladieItem;
import net.xiaxin.goba.item.TerraDaggerItem;
import net.xiaxin.goba.item.TerraBroadswordItem;
import net.xiaxin.goba.item.GobberkatananetherItem;
import net.xiaxin.goba.item.GobberkatanaendItem;
import net.xiaxin.goba.item.GobberhaladieItem;
import net.xiaxin.goba.item.GobberWaraxeNetherItem;
import net.xiaxin.goba.item.GobberWaraxeItem;
import net.xiaxin.goba.item.GobberWaraxeEndItem;
import net.xiaxin.goba.item.GobberSpearNetherItem;
import net.xiaxin.goba.item.GobberSpearItem;
import net.xiaxin.goba.item.GobberSpearEndItem;
import net.xiaxin.goba.item.GobberRapierNetherItem;
import net.xiaxin.goba.item.GobberRapierItem;
import net.xiaxin.goba.item.GobberRapierEndItem;
import net.xiaxin.goba.item.GobberKatanaItem;
import net.xiaxin.goba.item.GobberHaladieEndItem;
import net.xiaxin.goba.item.GobberDaggerNetherItem;
import net.xiaxin.goba.item.GobberDaggerItem;
import net.xiaxin.goba.item.GobberDaggerEndItem;
import net.xiaxin.goba.item.GobberBroadswordNetherItem;
import net.xiaxin.goba.item.GobberBroadswordItem;
import net.xiaxin.goba.item.GobberBroadswordEndItem;
import net.xiaxin.goba.GateOfBabylonAdditionsMod;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

public class GateOfBabylonAdditionsModItems {
	public static Item GOBBER_KATANA;
	public static Item GOBBER_KATANA_NETHER;
	public static Item GOBBER_KATANA_END;
	public static Item TERRA_KATANA;
	public static Item GOBBER_RAPIER;
	public static Item GOBBER_RAPIER_NETHER;
	public static Item GOBBER_RAPIER_END;
	public static Item TERRA_RAPIER;
	public static Item GOBBER_BROADSWORD;
	public static Item GOBBER_BROADSWORD_NETHER;
	public static Item GOBBER_BROADSWORD_END;
	public static Item TERRA_BROADSWORD;
	public static Item GOBBER_WARAXE;
	public static Item GOBBER_WARAXE_NETHER;
	public static Item GOBBER_WARAXE_END;
	public static Item TERRA_WARAXE;
	public static Item GOBBER_SPEAR;
	public static Item GOBBER_SPEAR_NETHER;
	public static Item GOBBER_SPEAR_END;
	public static Item TERRA_SPEAR;
	public static Item GOBBER_DAGGER;
	public static Item GOBBER_DAGGER_NETHER;
	public static Item GOBBER_HALADIE_NETHER;
	public static Item GOBBER_HALADIE_END;
	public static Item TERRA_HALADIE;
	public static Item GOBBER_DAGGER_END;
	public static Item TERRA_DAGGER;

	public static void load() {
		GOBBER_KATANA = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_katana"),
				new GobberKatanaItem());
		GOBBER_KATANA_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_katana_nether"),
				new GobberkatananetherItem());
		GOBBER_KATANA_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_katana_end"),
				new GobberkatanaendItem());
		TERRA_KATANA = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_katana"),
				new TerrasteelKatanaItem());
		GOBBER_RAPIER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_rapier"),
				new GobberRapierItem());
		GOBBER_RAPIER_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_rapier_nether"),
				new GobberRapierNetherItem());
		GOBBER_RAPIER_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_rapier_end"),
				new GobberRapierEndItem());
		TERRA_RAPIER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_rapier"), new TerraRapierItem());
		GOBBER_BROADSWORD = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_broadsword"),
				new GobberBroadswordItem());
		GOBBER_BROADSWORD_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_broadsword_nether"),
				new GobberBroadswordNetherItem());
		GOBBER_BROADSWORD_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_broadsword_end"),
				new GobberBroadswordEndItem());
		TERRA_BROADSWORD = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_broadsword"),
				new TerraBroadswordItem());
		GOBBER_WARAXE = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_waraxe"),
				new GobberWaraxeItem());
		GOBBER_WARAXE_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_waraxe_nether"),
				new GobberWaraxeNetherItem());
		GOBBER_WARAXE_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_waraxe_end"),
				new GobberWaraxeEndItem());
		TERRA_WARAXE = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_waraxe"), new TerraWaraxeItem());
		GOBBER_SPEAR = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_spear"), new GobberSpearItem());
		GOBBER_SPEAR_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_spear_nether"),
				new GobberSpearNetherItem());
		GOBBER_SPEAR_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_spear_end"),
				new GobberSpearEndItem());
		TERRA_SPEAR = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_spear"), new TerraSpearItem());
		GOBBER_DAGGER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_dagger"),
				new GobberDaggerItem());
		GOBBER_DAGGER_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_dagger_nether"),
				new GobberDaggerNetherItem());
		GOBBER_HALADIE_NETHER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_haladie_nether"),
				new GobberhaladieItem());
		GOBBER_HALADIE_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_haladie_end"),
				new GobberHaladieEndItem());
		TERRA_HALADIE = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_haladie"),
				new TerraHaladieItem());
		GOBBER_DAGGER_END = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "gobber_dagger_end"),
				new GobberDaggerEndItem());
		TERRA_DAGGER = Registry.register(Registry.ITEM, new ResourceLocation(GateOfBabylonAdditionsMod.MODID, "terra_dagger"), new TerraDaggerItem());
	}
}
